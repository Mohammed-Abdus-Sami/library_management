
async function loadBooks(){

const res = await fetch("http://localhost:5000/books")
const books = await res.json()

let html=""

books.forEach(b=>{
html += `<div>
<h3>${b.title}</h3>
<p>${b.author}</p>
</div>`
})

document.getElementById("books").innerHTML = html

}

async function addBook(){

const title = document.getElementById("title").value
const author = document.getElementById("author").value

await fetch("http://localhost:5000/add-book",{
method:"POST",
headers:{ "Content-Type":"application/json"},
body:JSON.stringify({title,author})
})

alert("Book Added")

}
