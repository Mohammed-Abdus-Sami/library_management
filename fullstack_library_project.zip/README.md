
Full Stack Library Management System

Tech Stack
Frontend: HTML CSS JavaScript
Backend: Python Flask
Database: SQLite

How to Run

1 Install dependencies
pip install flask flask-cors

2 Run backend
cd backend
python app.py

3 Open frontend
Open frontend/index.html in browser

Features
Add books
View books
Simple REST API
