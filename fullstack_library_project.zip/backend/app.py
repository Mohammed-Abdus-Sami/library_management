
from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3

app = Flask(__name__)
CORS(app)

def get_db():
    conn = sqlite3.connect("database.db")
    conn.row_factory = sqlite3.Row
    return conn

@app.route("/")
def home():
    return "Library API Running"

@app.route("/books", methods=["GET"])
def get_books():
    conn = get_db()
    books = conn.execute("SELECT * FROM books").fetchall()
    return jsonify([dict(b) for b in books])

@app.route("/add-book", methods=["POST"])
def add_book():
    data = request.json
    conn = get_db()
    conn.execute(
        "INSERT INTO books (title, author, available) VALUES (?, ?, 1)",
        (data["title"], data["author"]),
    )
    conn.commit()
    return jsonify({"message": "Book added successfully"})

@app.route("/register", methods=["POST"])
def register():
    data = request.json
    conn = get_db()
    conn.execute(
        "INSERT INTO users (name,email,password) VALUES (?,?,?)",
        (data["name"], data["email"], data["password"]),
    )
    conn.commit()
    return jsonify({"message": "User registered"})

if __name__ == "__main__":
    app.run(debug=True)
